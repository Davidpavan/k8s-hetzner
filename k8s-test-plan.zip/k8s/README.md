# AKS/EKS Test Plan

- [Multi-Cluster Visibility](./visibility.ipynb)
- [Multi-Cluster Optimization to reduce costs](./optimization.ipynb)
- [Automation to increase DevOps productivity](./automation.ipynb)
